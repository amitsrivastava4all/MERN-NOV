import React from 'react';
// Step -1 Context Create
export const CounterContext = React.createContext({count:0, setCount:()=>null});