import React from 'react'
import { useContext } from 'react'
import { CounterContext } from '../app/counter-context'

const Increment = React.memo(() => {
    const context= useContext(CounterContext);
  const plus = ()=>{
    context.setCount(context.count + 1);
  }  
  return (
    <div>
        <button onClick={plus}>+</button>
    </div>
  )
});

export default Increment