import React, { useContext } from 'react'
import { CounterContext } from '../app/counter-context'

const Result = () => {
    const context = useContext(CounterContext);
  return (
    <div>
        <h1>Result is {context.count}</h1>
    </div>
  )
}

export default Result