import React from 'react'
import Increment from '../components/Increment'
import Result from '../components/Result'
import { useState } from 'react'
import { CounterContext } from '../app/counter-context'

const Home = () => {
    const [count, setCount ]=useState(0);
  return (
    <div>
        <CounterContext.Provider value={{count:count, setCount:setCount}}>
        <Increment/>
        <Result/>
        </CounterContext.Provider>
    </div>
  )
}

export default Home