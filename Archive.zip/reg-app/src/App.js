import logo from './logo.svg';
import './App.css';
import Register from './components/Register';

function App() {
  return (
    <Register/>
  );
}

export default App;
