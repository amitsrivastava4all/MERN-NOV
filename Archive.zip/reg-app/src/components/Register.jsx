import React from 'react'
import { useState } from 'react';
import { useRef } from 'react';

const Register = () => {
    const [error, setError] = useState({});
    const userid = useRef('');
    const password = useRef('');
    const name = useRef('');
  const takeUserId= (event)=>{
    const val = event.target.value;
    if(val.length<8){
        setError({'useriderr':'Userid cannot less than 8 chars'});
    }
    console.log('Value is ',val);
  }  
  const doRegister = ()=>{
    const useridValue = userid.current.value;
    const passwordValue = password.current.value;
    const nameValue = name.current.value;
    console.log('Userid ',useridValue, ' Password ',passwordValue, ' NAme ', nameValue);
  }
  return (
    <div>
        <h1>Register</h1>
        <input type='text' ref = {userid} placeholder='Type Userid Here'/>
        {error?.useriderr?<span>Userid cant be less than 8 chars</span>:<></>}
        <br/>
        <input ref={password} type='password' placeholder='Type Password Here'/>
        <br/>
        <input ref={name} type='text' placeholder='Type Name Here'/>
        <br/>
        <button onClick={doRegister}>Register</button>
    </div>
  )
}

export default Register