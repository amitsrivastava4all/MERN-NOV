export const Button = ({label, myclass, fn})=>{
    let myClassName = `btn btn-${myclass}`;
    return (<button onClick={fn} className={myClassName}>{label}</button>)
}