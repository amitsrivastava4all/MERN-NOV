import { useState } from "react";
import { Button } from "../components/Button"
import { Label } from "../components/Label"

export const CounterApp = ()=>{
    console.log('Call Again...');
    const [count , setCount] = useState(0); // state initalize with 0 value
    //let count2  = 0;
    const plus = ()=>{
        //count = count + 1;
        setCount(count + 1)
        console.log('Plus Count is ', count);
    }
    const minus = ()=>{
        //count2 = count2 -1;
        setCount(count - 1);
        //console.log('Minus Count is ', count2);
    }
    return (<>
        <Label title="Counter App"/>
        <Button fn = {plus} label="+" myclass="success"/> &nbsp;
        <Button fn = {minus} label="-" myclass="danger"/>
        <Label title = "Counter is " val = {count}/>
    </>)
}