// Write the First Component
import './App.css';
import React from "react";
import { First } from './components/First';
import { Second } from './components/Second';
import Third from './components/Third';
import Fourth from './components/Fourth';
// document.createElement('h1'); // DOM Element
// Every Component is a Function
const App = ()=>{
  const value = 3;
  const conditionalRendering = ()=>{
    if(value==1){
      return <First msg="Hi " fn = {myFunction}/>
    }
    else if (value ==2){
      return <Second/>
    }
    else if (value ==3){
      return <Third/>
    }
    else if (value == 4){
      return <Fourth/>
    }
    else {
      return <h1>Nothing...</h1>
    }
  }
  const flag = true;
  const myStyle = {
    color : 'green',
    backgroundColor :'red'
  };
  const myName = 'Amit Srivastava';
  const myFunction = (value)=>{
    console.log("I am the App Function.... ", value);
  }
  return (<>
  {/* {flag?<First fn = {myFunction} msg = "Hi First.... "/>:<Second/>} */}
  
  {conditionalRendering()}
  <h1 className='red'>Hello React JS {myName}</h1>
   <h1 style = {myStyle}>Hi React JS</h1></>)
  // return (<div>
  //   <h1>Hello React JS</h1>
  //   <p>Hi <span>React JS</span></p>
  // </div>)
  //return React.createElement('div',null,React.createElement('h1',null, 'Hello React JS'), React.createElement('p', null, 'Hi', React.createElement('span', null, 'React JS')));
  //return (<h1>Hi React JS </h1>)
  //return React.createElement('h1',{style:{backgroundColor:'red'}},'Hi React JS') // Virtual DOM Element
}
export default App;