// Write the First Component
import './App.css';
import React from "react";
// document.createElement('h1'); // DOM Element
// Every Component is a Function
const App = ()=>{
  const myStyle = {
    color : 'green',
    backgroundColor :'red'
  };
  const myName = 'Amit Srivastava';
  return (<><h1 className='red'>Hello React JS {myName}</h1>
   <h1 style = {myStyle}>Hi React JS</h1></>)
  // return (<div>
  //   <h1>Hello React JS</h1>
  //   <p>Hi <span>React JS</span></p>
  // </div>)
  //return React.createElement('div',null,React.createElement('h1',null, 'Hello React JS'), React.createElement('p', null, 'Hi', React.createElement('span', null, 'React JS')));
  //return (<h1>Hi React JS </h1>)
  //return React.createElement('h1',{style:{backgroundColor:'red'}},'Hi React JS') // Virtual DOM Element
}
export default App;