//export const First = (props)=>{
    export const First = ({msg , fn})=>{
    //console.log('type ', typeof props);
    // return (<h1>First Component {props.msg} </h1>)
    fn(1000);
    return (<h1>First Component {msg} </h1>)
}