import React from 'react'

const Fourth = () => {
  return (
    <div>
        <h1>Fourth Component</h1>
    </div>
  )
}

export default Fourth