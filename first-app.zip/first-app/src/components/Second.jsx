export const Second = ()=>{
    return (<h1>I am the Second Component</h1>)
}