import React from 'react'

const Third = () => {
    //const fruits = ["Orange", "Apple", "Mango"]; // Array of String
    const products = [{id:101, name:'Puma', price:2222, url :'https://rukminim1.flixcart.com/image/612/612/xif0q/shoe/y/f/w/-original-imaggc8krsfkqhmq.jpeg'}, {id:1002, name:'Adidas', price:4444, url :'https://rukminim1.flixcart.com/image/612/612/xif0q/shoe/q/a/e/-original-imaggcb6my2makpg.jpeg'}]; // Array of Objects
  return (
    <div>
        <h1>Third Component</h1>
        {/* {fruits.map((fruit,index)=><h1 key={index}>{fruit} Fruit</h1>)} */}
        {products.map(product=><div key={product.id}>
            <img src = {product.url} alt = {product.name}/>
            <p>Id {product.id} Name {product.name} Price {product.price} </p>
        </div>)}
    </div>
  )
}

export default Third