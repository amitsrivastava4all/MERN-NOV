// DOM 
// Destructure
import { GoogleAuthProvider } from "https://www.gstatic.com/firebasejs/9.15.0/firebase-auth.js";
import { loginWithGmail } from "../../shared/services/oauth.js";
window.addEventListener('load', bindEvents);
// Controller it is a Glue B/w View and Model
function bindEvents(){
    const button = document.querySelector('#teacher-login');
    button.addEventListener('click', doLogin);
}
function doLogin(){
    const promise = loginWithGmail();
    promise.then((result) => {
        // This gives you a Google Access Token. You can use it to access the Google API.
        const credential = GoogleAuthProvider.credentialFromResult(result);
        const token = credential.accessToken;
        // The signed-in user info.
        const user = result.user;
        // sessionStorage (HTML5)
        sessionStorage.userName = user.displayName;
        console.log('User Info is ',user);
        // Redirect to the DashBoard
        location.href = 'dashboard.html';
        // ...
      }).catch((err) => {
        console.log('Error in OAuth ', err);
        // Handle Errors here.
        // const errorCode = error.code;
        // const errorMessage = error.message;
        // // The email of the user's account used.
        // const email = error.customData.email;
        // // The AuthCredential type that was used.
        // const credential = GoogleAuthProvider.credentialFromError(error);
        // ...
      });
}