// DOM 
window.addEventListener('load', bindEvents);
function bindEvents(){
    document.querySelector('#add').addEventListener('click', addQuestion);
}
const fields = ["id", "name", "option-a","option-b","option-c","option-d","right-ans","score"];
function addQuestion(){
    const questionObject= {}; // Object Literal
    for(let field of fields){
        let value = document.querySelector(`#${field}`).value;
        questionObject[field] = value;
    }
    console.log('Question Object is ', questionObject);
    console.log('Type of ', typeof questionObject, ' Instance of ', questionObject instanceof Object);
    // Read all the fields
    // DRY
    // document.querySelectorAll(".form-control")
    // let name = document.querySelector('#name').value;
    // let id = document.querySelector('#id').value;
    // let optionA = document.querySelector('#option-a').value;
}