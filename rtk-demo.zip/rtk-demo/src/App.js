import logo from './logo.svg';
import './App.css';
import UserHome from './pages/UserHome';

function App() {
  return (
    <UserHome/>
  );
}

export default App;
