import React from 'react'
import Add from '../modules/user/components/Add'
import View from '../modules/user/components/View'

const UserHome = () => {
  return (
    <>    
    <Add/>
    <hr/>
    <View/>
    </>

  )
}

export default UserHome