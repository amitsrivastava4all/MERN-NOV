import React from 'react'

const Cart = () => {
  return (
    <div>Cart Component</div>
  )
}

export default Cart