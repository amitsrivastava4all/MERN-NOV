import React from 'react'

const Order = () => {
  return (
    <div>Order Component</div>
  )
}

export default Order