import React from 'react'
import Menu from '../../../shared/widgets/Menu'
import Container from '@mui/material/Container';
import Products from '../components/Products';
import AppRouting from '../../../settings/app-routing';
import { DynamicRoutes } from '../../../settings/dynamic-routes';
const Home = () => {
  return (
    <Container maxWidth="sm">
        <Menu/>
        <hr/>
        {/* <AppRouting/> */}
        <DynamicRoutes/>
        </Container>
    
  )
}

export default Home