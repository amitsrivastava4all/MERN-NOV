import React from 'react'
import { useSearchParams } from 'react-router-dom'

const Login = () => {
  const [searchParams] = useSearchParams();
  
  //console.log('Params Rec is ', searchParams);
  for(let x of searchParams.entries()){
    console.log(x);
  }
  searchParams.forEach(e=>console.log('Params are ', e));
  return (
    <div>Login Component</div>
  )
}

export default Login