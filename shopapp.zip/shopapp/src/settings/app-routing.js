import React from 'react'
import {Route,Routes} from 'react-router-dom';
import Products from '../modules/product/components/Products';
import Login from '../modules/user/pages/Login';
import Register from '../modules/user/pages/Register';
import Order from '../modules/orders/pages/Order';
import ErrorPage from '../shared/components/ErrorPage';
const AppRouting = () => {
  return (
       <Routes>
        <Route  path="/" element = {<Products/>}/>
        <Route path="/login" element = {<Login/>}/>
        <Route path="/register/:socialmedia" element = {<Register/>}/>
        <Route path="/orders" element = {<Order/>}/>
        <Route path='*' element = {<ErrorPage/>} />
       </Routes>
  );
}

export default AppRouting;