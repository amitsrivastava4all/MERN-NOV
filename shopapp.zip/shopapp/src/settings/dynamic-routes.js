import { useRoutes } from "react-router-dom"
import Login from "../modules/user/pages/Login";
import Register from "../modules/user/pages/Register";
import Order from "../modules/orders/pages/Order";
import Products from "../modules/product/components/Products";
import Home from "../modules/product/pages/Home";

export const DynamicRoutes = ()=>{
    // API Calls
    const routeObject = [{
        path:'/', element: <Products/>
    },
    {
        path:'/login', element: <Login/>
    },
        {path:'/register', element: <Register/>},
        {path:'/orders', element: <Order/>},
        {path:'/products', element: <Products/>}
    ];
    const jsxElements =  useRoutes(routeObject);
    console.log('JSX ',jsxElements);
    return jsxElements;
}