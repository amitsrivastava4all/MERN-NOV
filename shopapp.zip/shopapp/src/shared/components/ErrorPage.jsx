import React from 'react'

const ErrorPage = () => {
  return (
    <div>OOPS U Type Something Wrong...</div>
  )
}

export default ErrorPage