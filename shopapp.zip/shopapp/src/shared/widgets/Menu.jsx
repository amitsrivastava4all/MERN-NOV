import React from 'react'
import Link from '@mui/material/Link';
import {NavLink} from 'react-router-dom';
const Menu = () => {
  return (
    <div>
        <NavLink to="/">Home</NavLink>
        &nbsp;
        <NavLink to="/login?type=otp">Login</NavLink>
        &nbsp;
        <NavLink to="/register/FB">Register</NavLink>
        &nbsp;
        <NavLink to="/carts">Carts</NavLink>
        &nbsp;
        <NavLink to="/orders">Orders</NavLink>
        
    </div>
  )
}

export default Menu