import React from 'react'
import { Routes } from 'react-router-dom';
import PublicRoute from './public-routes';
import PrivateRoute from './private-routes';
import DashBoard from '../../pages/DashBoard';
import About from '../../pages/About';
import News from '../../pages/News';

const AllRoutes = () => {
  return (
    <Routes>
        
        <PublicRoute restricted={false} component={DashBoard} path="/dashboard" exact />
        <PublicRoute restricted={false} component={About} path="/about" exact />
        <PublicRoute restricted={false} component={News} path="/news" exact />

        <PrivateRoute component={DashBoard} path="/dashboard" exact />
    </Routes>
  )
}

export default AllRoutes;