
import {configureStore} from '@reduxjs/toolkit';
import productSlice from '../modules/products/redux/product-slice';
import cartSlice from '../modules/carts/redux/cart-slice';
export const store = configureStore({
    reducer:{'productsSlice':productSlice, 'cartSlice':cartSlice}
})