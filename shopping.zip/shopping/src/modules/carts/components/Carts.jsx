import * as React from 'react';
import Button from '@mui/material/Button';
import Dialog from '@mui/material/Dialog';
import ListItemText from '@mui/material/ListItemText';
import ListItem from '@mui/material/ListItem';
import List from '@mui/material/List';
import Divider from '@mui/material/Divider';
import AppBar from '@mui/material/AppBar';
import Toolbar from '@mui/material/Toolbar';
import IconButton from '@mui/material/IconButton';
import Typography from '@mui/material/Typography';
import CloseIcon from '@mui/icons-material/Close';
import Slide from '@mui/material/Slide';
import Badge from '@mui/material/Badge';
import ShoppingCartIcon from '@mui/icons-material/ShoppingCart';
import { loginWithGmail } from '../redux/cart-slice';
import {useDispatch, useSelector} from 'react-redux';
import { handlePayment } from '../../../shared/services/razor-pay';
import useRazorpay from "react-razorpay";

const Transition = React.forwardRef(function Transition(props, ref) {
  return <Slide direction="up" ref={ref} {...props} />;
});

export const Carts=({total, carts})=> {
  const Razorpay = useRazorpay();
  const userInfo = useSelector(state=>state);
  console.log('User Info ', userInfo);
  const [open, setOpen] = React.useState(false);
  const dispatch = useDispatch();
  const handleClickOpen = () => {
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
  };

  const checkOut = ()=>{
   
    dispatch(loginWithGmail({Razorpay,name:'Ram', amount:111*60}));
    
  }

  return (
    <div>
      <Badge badgeContent={total} color="primary">
            <IconButton onClick={handleClickOpen}>
          <ShoppingCartIcon />  
          </IconButton>
          </Badge>
      <Dialog
        fullScreen
        open={open}
        onClose={handleClose}
        TransitionComponent={Transition}
      >
        <AppBar sx={{ position: 'relative' ,backgroundColor:'black'}}>
          <Toolbar>
            <IconButton
              edge="start"
              color="inherit"
              onClick={handleClose}
              aria-label="close"
            >
              <CloseIcon />
            </IconButton>
            <Typography sx={{ ml: 2, flex: 1 }} variant="h6" component="div">
              Items in Cart
            </Typography>
            <Button autoFocus color="inherit" onClick={handleClose}>
              Buy Now
            </Button>
          </Toolbar>
        </AppBar>
        <List>
        {carts.map((cart)=>{
          console.log('Cart ', cart);
        return (<><ListItem >
          
            <img style={{width:'100px',height:'100px'}} src = {cart.product.image} alt='No Image'/>

          <ListItemText primary={cart.product.title} secondary={cart.product.price}></ListItemText>
          </ListItem>
          <Divider/>
          </>)
})}
        </List>
        <Button onClick={checkOut} color='success' variant="contained">Checkout</Button>
        {/* <List>
          <ListItem button>
            <ListItemText primary="Phone ringtone" secondary="Titania" />
          </ListItem>
          <Divider />
          <ListItem button>
            <ListItemText
              primary="Default notification ringtone"
              secondary="Tethys"
            />
          </ListItem>
        </List> */}
      </Dialog>
    </div>
  );
}