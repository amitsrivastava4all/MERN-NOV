import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import { signInWithGoogle } from "../../../shared/services/google-oauth";
import { handlePayment } from "../../../shared/services/razor-pay";

export const loginWithGmail = createAsyncThunk('loginwithgmail',async ( params)=>{
//      signInWithGoogle().then(user => {
//         localStorage.user = user;
//         console.log('User:::::: ', user);
//    }).catch(err=>{
//      console.log('Error OAuth ', err);
//    });
try{
   const user =  await signInWithGoogle();
   console.log(':::Login with Gmail ', user);
   localStorage.email= user.email;
   handlePayment(params.Razorpay, params);
   
   return user;
}
catch(err){
console.log('Error is ::: ', err);
return err;
}

  
 })
const cartSlice = createSlice({
    name:'cartSlice',
    initialState:{carts:[], total:0, amount:0, loading:false},
    reducers:{
        addToCart(state, action){
                state.carts.push(action.payload);
                state.total = state.carts.length;
                console.log('State Change... In Add ', state);
        },
        totalItemsInCart(state, action){
            state.total = state.carts.length;
        },
        totalAmount(state, action){
            state.amount = state.carts.reduce((acc, cart)=>acc+cart.price, 0);
        }
    },
    extraReducers:{
        [loginWithGmail.pending] :(state,action)=>{
            state.loading = true;
        },
        [loginWithGmail.fulfilled] :(state,action)=>{
            state.loading = false;
            state.users = action.payload;
        },
        [loginWithGmail.rejected] :(state,action)=>{
            state.loading = false;
            state.error = action.payload;
        }
    }
});
export const {addToCart, totalItemsInCart, totalAmount}  = cartSlice.actions;
export default cartSlice.reducer;
