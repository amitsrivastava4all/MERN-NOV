import React from 'react'
import Grid from '@mui/material/Grid';
import { ProductCard } from '../../../shared/widgets/Card';
import {useDispatch} from 'react-redux';
import { addToCart } from '../../carts/redux/cart-slice';
const Product = ({product}) => {
  const dispatch= useDispatch();
  const addItemToCart = (currentProduct)=>{
    dispatch(addToCart({product:currentProduct}));
  }
  return (
    <Grid  item xs={2}  key={product.id}>
            <ProductCard product = {product} fn = {addItemToCart}/>
          </Grid>
  )
}

export default Product