import React, { useEffect } from 'react'
import { apiClient } from '../../../shared/services/api-client';
import { fetchProducts } from '../redux/product-slice';
import { useDispatch, useSelector } from 'react-redux';
import Product from './Product';

const Products = () => {
   const state= useSelector(state=>state);
   console.log('Products .... ', state);
   const dispatch = useDispatch();
   useEffect(async ()=>{
   // return function(){}
    const products = await dispatch(fetchProducts());
    console.log('Fetch Products ::: ',products);
   },[])
  return (
    <>
     
    {state.productsSlice.loading?<p>Loading....</p>:state.productsSlice.products.data.map(product=><Product product={product}/>)}
    </>
  )
}

export default Products