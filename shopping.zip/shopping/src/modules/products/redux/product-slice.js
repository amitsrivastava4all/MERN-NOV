import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import { apiClient } from "../../../shared/services/api-client";
export const fetchProducts = createAsyncThunk('fetch-products',async ()=>{
   const result =  await apiClient.get(process.env.REACT_APP_PRODUCT_URL);
   return result; // result wrap promise
})
const productSlice = createSlice({
    name:'products-slice',
    initialState:{'products':[],'loading':true},
    reducers:{

    },
    extraReducers:(builder)=>{
        builder.addCase(fetchProducts.pending,(state,action)=>{
            state.loading = true;
        }).addCase(fetchProducts.fulfilled, (state, action)=>{
            state.loading = false; 
            state.products = action.payload;
        }).addCase(fetchProducts.rejected,(state, action)=>{
            state.loading = false; 
        state.error = action.payload;
        })
    }
    /*extraReducers: {
        [fetchProducts.pending] : (state, action)=>{
               state.loading = true; 
        },
        [fetchProducts.fulfilled] : (state, action)=>{
            state.loading = false; 
            state.products = action.payload;
     } ,
     [fetchProducts.rejected] : (state, action)=>{
        state.loading = false; 
        state.error = action.payload;
 }    
    }*/
    }


);

export default productSlice.reducer;