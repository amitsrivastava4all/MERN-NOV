import React from 'react'

const About = () => {
  return (
    <div>About Shopping</div>
  )
}

export default About