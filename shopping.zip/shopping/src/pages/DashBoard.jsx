import React from 'react'

const DashBoard = () => {
  return (
    <div>Shopping DashBoard</div>
  )
}

export default DashBoard