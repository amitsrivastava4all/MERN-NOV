import React from 'react'

const News = () => {
  return (
    <div>Shopping News</div>
  )
}

export default News