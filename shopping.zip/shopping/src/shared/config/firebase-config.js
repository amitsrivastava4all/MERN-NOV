// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import { getAnalytics } from "firebase/analytics";
import { getAuth } from "firebase/auth";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyAwEw3NIZpME3wCt6AmAuxj3p4W0m0H9c0",
  authDomain: "shop-auth-88321.firebaseapp.com",
  projectId: "shop-auth-88321",
  storageBucket: "shop-auth-88321.appspot.com",
  messagingSenderId: "192842228747",
  appId: "1:192842228747:web:35264f3989745f9040930e",
  measurementId: "G-KHZL0898L0"
};

// Initialize Firebase
export const firebaseapp = initializeApp(firebaseConfig);

const analytics = getAnalytics(firebaseapp);

export const authFB = getAuth(firebaseapp);