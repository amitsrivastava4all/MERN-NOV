import axios from 'axios';
axios.defaults.baseURL = process.env.REACT_APP_BASE_URL;
axios.defaults.timeout=process.env.REACT_APP_TIMEOUT;
export const apiClient = {
    get(url){
        return axios.get(url);
        //return axios.get(url,{timeout:4000});
    }
}