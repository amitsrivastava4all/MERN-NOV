import {  signInWithPopup, GoogleAuthProvider } from "firebase/auth";
import {authFB} from '../config/firebase-config';
const auth = authFB;
const provider = new GoogleAuthProvider();
export const signInWithGoogle = async ()=>{
    try {
        const res = await signInWithPopup(auth, provider);
        const user = res.user;
        console.log('Logged In ', user);
        return user;
    }
    catch(err){
        console.log('Error is ', err);
        return err;
    }
}