


export const handlePayment =  (Razorpay,params) => {
  //const order = await createOrder(params); //  Create order on your backend
  //const Razorpay = useRazorpay();
  console.log('Params ', params, 'Amount is ::::', params.amount);
  const options = {
    key: "rzp_test_SRAmq63Pf30PNE", // Enter the Key ID generated from the Dashboard
    amount: params.amount, // Amount is in currency subunits. Default currency is INR. Hence, 50000 refers to 50000 paise
    currency: "INR",
    name: params.name,
    description: "Test Transaction",
    image: "https://media.licdn.com/dms/image/C560BAQFnAbpvMrRsJQ/company-logo_200_200/0/1592976276357?e=2147483647&v=beta&t=W7Q_wHmDVamXAQXWp88nZIRGd1TtH5s1ScGqhJwkZF4",
    //order_id: "order_9A33XWu170gUtm", //This is a sample Order ID. Pass the `id` obtained in the response of createOrder().
    handler: function (response) {
      alert('Payment Done SuccessFully Order id '+response.razorpay_payment_id);
      //alert(response.razorpay_order_id);
      //alert(response.razorpay_signature);
    },
    prefill: {
      name: "Amit Srivastava",
      email: "amit@brain-mentors.com",
      contact: "9999999999",
    },
    notes: {
      address: "Brain Mentors Corporate Office",
    },
    theme: {
      color: "#3399cc",
    },
  };
  console.log('Razor Pay ',Razorpay, ' and ', params);
  const rzp1 = new Razorpay(options);

  rzp1.on("payment.failed", function (response) {
    alert(response.error.code);
    alert(response.error.description);
    alert(response.error.source);
    alert(response.error.step);
    alert(response.error.reason);
    alert(response.error.metadata.order_id);
    alert(response.error.metadata.payment_id);
  });

  rzp1.open();
  return "Done";
};
