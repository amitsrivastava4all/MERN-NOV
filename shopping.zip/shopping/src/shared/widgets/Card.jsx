import React from 'react'
import Card from '@mui/material/Card';
import CardHeader from '@mui/material/CardHeader';
import CardMedia from '@mui/material/CardMedia';
import CardContent from '@mui/material/CardContent';
import CardActions from '@mui/material/CardActions';
import Rating from '@mui/material/Rating';
import AddShoppingCartIcon from '@mui/icons-material/AddShoppingCart';
import Typography from '@mui/material/Typography';
import { IconButton } from '@mui/material';
export const ProductCard = ({product, fn}) => {
  return (
    <Card sx={{ maxWidth: 345, border: '2px solid grey',':hover': {
        boxShadow: 20, 
        
       
      } }}>
      <CardHeader
       
        title={product.title.substring(0,10)}
        subheader=""
      />
      <CardMedia
        component="img"
        height="194"
        image={product.image}
        alt="No Image..."
      />
      <CardContent>
        <Typography variant="body2" color="text.secondary">
          {product.price}
        </Typography>
      </CardContent>
      <CardActions disableSpacing>
        
        <IconButton color='primary' onClick={()=>fn(product)}>
            <AddShoppingCartIcon/>
        </IconButton>
        <Rating name="read-only" value={product.rating.rate} readOnly />
      </CardActions>
      
    </Card>

  )
}
export default Card