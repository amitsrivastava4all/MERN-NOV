import React from 'react'
import {NavLink} from 'react-router-dom';
const Menu = () => {
  return (
    <div>
        
<NavLink to="/about">
        About
</NavLink>
<NavLink to="/news">
        About
</NavLink>
<NavLink to="/dashboard">
        About
</NavLink>
    </div>
  )
}

export default Menu