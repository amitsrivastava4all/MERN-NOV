import { ClassGrid } from "./pages/ClassGrid";
import Grid from "./pages/Grid";

const App = ()=>{
  //return (<Grid/>);
  return (<ClassGrid/>)
}
export default App;