import React from 'react'
import Box from './Box'
import { useState } from 'react'

const Board = () => {
    // Array for Maintain 9 Box Status
    let message = '';
    const [boxValues, setBoxValues] = useState(Array(9).fill(''));
   
   // True - X , False 0  
   const [isXorZero, setXorZero] = useState(false);
   const possibleWays = [[0,1,2],[3,4,5],[6,7,8],[0,3,6],[1,4,7],[2,5,8],[0,4,8],[2,4,6]]; 
   const gameOver = ()=>{
        for(let way of possibleWays){
            return allThreeSame(way[0], way[1], way[2])
        }
   }
   const allThreeSame = (first, second, third)=>{
    return boxValues[first] &&  boxValues[first] === boxValues[second] && boxValues[first] === boxValues[third]
}
   const isGameOver = gameOver();
   if(isGameOver){
    message = 'Game Over';
}

  const doClick = (index)=>{
    const cloneArray = [...boxValues];
    console.log('Button Clicked ... ', index);
    if(!boxValues[index]){
    if(isXorZero){
        cloneArray[index] = 'X';
    }
    else{
        cloneArray[index] = '0';
    }
    
    console.log('Array ', cloneArray);
    setXorZero(!isXorZero);
    setBoxValues(cloneArray);
}
    
   
  }  
  return (
    <div>
        <h1>TicTacToe Game</h1>
        <p>{message}</p>
        <table>
            <tr>
                <Box val={boxValues[0]} boxClickFn={()=>doClick(0)}/>
                <Box val={boxValues[1]} boxClickFn={()=>doClick(1)}/>
                <Box val={boxValues[2]} boxClickFn={()=>doClick(2)}/>
            </tr>
            <tr>
                <Box val={boxValues[3]} boxClickFn={()=>doClick(3)}/>
                <Box val={boxValues[4]} boxClickFn={()=>doClick(4)}/>
                <Box val={boxValues[5]} boxClickFn={()=>doClick(5)}/>
            </tr>
            <tr>
                <Box val={boxValues[6]} boxClickFn={()=>doClick(6)}/>
                <Box val={boxValues[7]} boxClickFn={()=>doClick(7)}/>
                <Box val={boxValues[8]} boxClickFn={()=>doClick(8)}/>
            </tr>
        </table>
    </div>
  )
}

export default Board