import React from 'react'

const Box = ({val, boxClickFn}) => {
    const myStyle = {
        width : '100px',
        height:'100px',
        backgroundColor:'cyan',
        fontSize:'20px'
    }
  return (
    <td>
        <button style={myStyle} onClick={boxClickFn}>{val}</button>
    </td>
  )
}

export default Box