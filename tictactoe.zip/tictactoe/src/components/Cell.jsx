import React from 'react'
import { useState } from 'react'

const Cell = ({isXorZero, fn}) => {
    console.log('Cell Render Call....');
  const [val, setVal] = useState('');  
  const toggle = (event)=>{
    //console.log(event.target);
     
    if(!val){
        fn(); // Parent setState
    setVal(isXorZero?"X":"0"); // Child SetState
    }
   
  }  
  return (
        <td>
            <button onClick={toggle} className='btn btn-primary'> {val} </button>
        </td>
  )
}

export default Cell;