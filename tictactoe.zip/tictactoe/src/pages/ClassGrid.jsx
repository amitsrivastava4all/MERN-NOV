import { Component } from "react";
import Cell from '../components/Cell'
export class ClassGrid extends Component {
    constructor(){
        super();
        console.log('Class based Component  ',this);
        this.state = {XorZeroFlag:false};
    }
    toggleIt(){
        console.log('I am this ', this);
        this.setState({XorZeroFlag:!this.state.XorZeroFlag});
        
    }
    render(){
        return (<div className='container'>
        <h1 className='alert-info text-center'>Tic Tac Toe Game</h1>
        <table >
            <tr>
                <Cell isXorZero = {this.state.XorZeroFlag} fn = {this.toggleIt} />
                <Cell isXorZero = {this.state.XorZeroFlag} fn = {this.toggleIt} /> 
                <Cell isXorZero = {this.state.XorZeroFlag} fn = {this.toggleIt} /> 
              
                </tr>
                
        </table>
    </div>);
    }
}