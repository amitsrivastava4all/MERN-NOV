import React from 'react'
import Cell from '../components/Cell'
import { useState } from 'react'

const Grid = (props) => {
    console.log('All Children ', props.children);
   // let XorZeroFlag = false;
   const [XorZeroFlag , setXorZeroFlag] = useState(false);  
  const toggleIt = ()=>{
    
    setXorZeroFlag(!XorZeroFlag);
       
  }  
  return (
    <div className='container'>
        <h1 className='alert-info text-center'>Tic Tac Toe Game</h1>
        <table >
            <tr>
                <Cell isXorZero = {XorZeroFlag} fn = {toggleIt} />
                <Cell isXorZero = {XorZeroFlag} fn = {toggleIt} /> 
                <Cell isXorZero = {XorZeroFlag} fn = {toggleIt} /> 
              
                </tr>
                <tr>
                <Cell isXorZero = {XorZeroFlag} fn = {toggleIt} />
                <Cell isXorZero = {XorZeroFlag} fn = {toggleIt} /> 
                <Cell isXorZero = {XorZeroFlag} fn = {toggleIt} /> 
                </tr>
                <tr>
                <Cell isXorZero = {XorZeroFlag} fn = {toggleIt} />
                <Cell isXorZero = {XorZeroFlag} fn = {toggleIt} /> 
                <Cell isXorZero = {XorZeroFlag} fn = {toggleIt} /> 
                </tr>
        </table>
    </div>
  )
}

export default Grid