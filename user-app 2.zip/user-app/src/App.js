import logo from './logo.svg';
import './App.css';
import Home from './pages/Home';
import { MyAppErrorBoundary } from './shared/components/Error';

function App() {
  return (
    <MyAppErrorBoundary>
   <Home/>
   </MyAppErrorBoundary>
  );
}

export default App;
