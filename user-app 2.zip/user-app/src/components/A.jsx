import { usePlusHook } from "../hooks/plus-hook"

export const A = ()=>{
    const [counter, plus, minus]  = usePlusHook(0);
    return (<>
    <button onClick={plus}>+</button>
    <button onClick={minus}> - </button>
    <p>Counter is {counter}</p>
    </>
    )
}