import React from 'react'
import { useState } from 'react'
import Login from '../components/Login'
import Register from '../components/Register'
import { UserContext } from '../app/user-context'
import { A } from '../components/A'

const Home = () => {
  
  const [screenFlag, setScreenFlag] = useState(true);
  const [userInfo, setUserInfo] = useState({});
  //throw new Error('Home Error...');
  const toggleIt = ()=>{
    console.log(process.env.REACT_APP_MUSIC_URL);
    //throw new Error('Home Error...');
        setScreenFlag(!screenFlag);
  }  
  return (
   <div className='container'>
      <A/>
        <button className='btn btn-info' onClick={toggleIt}>{screenFlag?"Go to Register":"Go to Login"}</button>
        <UserContext.Provider value={{user:userInfo,setUser:setUserInfo}}>
        {screenFlag?<Login/>:<Register/>}
        </UserContext.Provider>
   </div>
  )
}

export default Home