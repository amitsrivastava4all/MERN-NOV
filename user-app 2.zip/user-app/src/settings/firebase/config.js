// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import { getAnalytics } from "firebase/analytics";
import {getFirestore} from "@firebase/firestore"
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyCGiLStblIbrgeJjJB3_z9nF2P4yZHzD58",
  authDomain: "user-app-cb3da.firebaseapp.com",
  projectId: "user-app-cb3da",
  storageBucket: "user-app-cb3da.appspot.com",
  messagingSenderId: "637936890815",
  appId: "1:637936890815:web:1efcce80038cdaead5270a",
  measurementId: "G-2Y7PXHBRPR"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const analytics = getAnalytics(app);
export const firestore = getFirestore(app);