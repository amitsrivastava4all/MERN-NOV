import React from 'react';
export class MyAppErrorBoundary extends React.Component{
    constructor(props){
        super(props);
        console.log('MyAppErrorBoundary Constructor ', this);
        this.state = {hasError:false};
    }

    // static getDerivedStateFromError(error) {
    //     // Update state so the next render will show the fallback UI.
    //     return { hasError: true };
    //   }
    
    componentDidCatch(error, info){
        // used to log the error
        console.log('Component Did Catch ::: Error Occur ', error, 'Info ',info);
        //const backEndURL = 'http://192.168.1.20:2222/error-log';
       // fetch(backEndURL, {method:'POST', body:JSON.stringify(error)});
        this.setState({hasError: true});
    }
    render(){
        if(this.state.hasError){
            return <h1 className="alert-danger">OOPS Something Went Wrong...</h1>
        }
        else{
            return this.props.children;
        }
    }
}