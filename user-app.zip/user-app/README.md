1. Context API and useref
2. Form Hooks
3. FireBase Integeration
4. Custom Hooks
5. Cloud Deploy