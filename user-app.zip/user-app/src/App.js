import logo from './logo.svg';
import './App.css';
import Login from './modules/user/components/Login';
import UserApp from './modules/user/pages/UserApp';

function App() {
  return (
   <UserApp/>
  );
}

export default App;
