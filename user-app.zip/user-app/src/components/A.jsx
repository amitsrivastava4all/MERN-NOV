import { usePlusHook } from "../hooks/plus-hook"

export const A = ()=>{
    const [counter, plus, minus]  = usePlusHook(0);
    return (<>
    <p>Counter App Example</p>
    <button data-testid='plus' onClick={plus}>+</button>
    <button onClick={minus}> - </button>
    <p>Counter is <span data-testid='result'>{counter}</span></p>
    </>
    )
}