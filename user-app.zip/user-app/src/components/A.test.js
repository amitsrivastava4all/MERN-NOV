import  { render, screen,fireEvent } from '@testing-library/react';
import {A} from './A';
import userEvent from "@testing-library/user-event";
describe('A Suite',()=>{
test('renders Counter App Example ', () => {
  render(<A />);
  const pTag = screen.getByText(/Counter App Example/i);
  expect(pTag).toBeInTheDocument();
});
test('renders Counter App Not Exact Test ', () => {
    render(<A />);
    const pTag = screen.getByText('Counter App',{exact:false});
    expect(pTag).toBeInTheDocument();
  });

  test('plus button click and test ', async() => {
    render(<A />);
    const button = screen.getByTestId('plus');
    fireEvent.click(button);
    const r = screen.getByTestId('result');
    
    expect(r).toHaveTextContent('1');
    
  });

});
