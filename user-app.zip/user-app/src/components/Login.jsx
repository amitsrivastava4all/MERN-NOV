import React, { useContext } from 'react'
import { useRef } from 'react'
import { UserContext } from '../app/user-context';
import { collection, query, where, getDocs } from "firebase/firestore";
import { firestore } from '../settings/firebase/config';

const Login = React.memo(() => {
  const userid = useRef();
  const password = useRef();
  const name = useRef();  
  const context = useContext(UserContext);
  const doLogin = async ()=>{
    const userIdValue = userid.current.value;
    const passwordValue = password.current.value;
    const q1 = query(collection(firestore, "users"), where("userid", "==", userIdValue,"password","==",passwordValue));

    if(userIdValue){
      throw new Error('Simulating the Error for Error Boundary....');
    }
      
    const querySnapshot = await getDocs(q1); 
    querySnapshot.forEach((doc) => {
      // doc.data() is never undefined for query doc snapshots
      console.log(doc.id, " USER LOGIN => ", doc.data());
    });
   
  }  
  return (
    <>
    <p>Welcome {context?.user?.name}</p>
        <h1 className='text-center alert-info'>Login</h1>
        <div className='form-group'>
            <label htmlFor="">Userid</label>
            <input ref = {userid} type="text" className='form-control' placeholder='Type Userid Here' />
        </div>
        <div className='form-group'>
            <label htmlFor="">Password</label>
            <input ref={password} type="password" className='form-control' placeholder='Type Password Here' />
        </div>
        
        <div className='form-group'>
            <button className='btn btn-primary' onClick={doLogin}>Login</button>
        </div>
    </>
  )
});

export default Login