import { useState } from "react"

export const usePlusHook = (count=0)=>{
    const [counter, setCounter] = useState(count);
    const plus = ()=>{
        setCounter(counter+1);
    }
    const minus = ()=>{
        setCounter(counter-1);
    }
    return [counter, plus, minus];
}