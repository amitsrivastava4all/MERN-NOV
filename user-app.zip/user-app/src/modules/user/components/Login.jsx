import React from 'react'
import TextField from '../../../shared/widgets/TextField'
import PasswordField from '../../../shared/widgets/PasswordField'
import Button from '../../../shared/widgets/Button'

const Login = () => {
  const doLogin = ()=>{

  }
  return (
    <div className='container'>
        <h1>Login </h1>
        <TextField labelValue="Userid"/>
        <PasswordField labelValue="Password"/>
        <Button value="Login" buttonClick={doLogin} />
    </div>
  )
}

export default Login