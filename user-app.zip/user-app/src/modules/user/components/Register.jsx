import React from 'react'
import TextField from '../../../shared/widgets/TextField'
import PasswordField from '../../../shared/widgets/PasswordField'
import Button from '../../../shared/widgets/Button'

const Register = () => {
  const doRegister = ()=>{

  }
  return (
    <div className='container'>
        <h1>Register </h1>
        <TextField labelValue="Userid"/>
        <PasswordField labelValue="Password"/>
        <TextField labelValue="Name"/>
        <TextField labelValue="Phone"/>
        <TextField labelValue="Email"/>
        <Button value="Register" buttonClick={doRegister} />
    </div>
  )
}

export default Register;