import React from 'react'
import Login from '../components/Login'
import Register from '../components/Register'
import Button from '../../../shared/widgets/Button'

const UserApp = () => {
  const routeIt = ()=>{

  } 
  return (
    <div>
        <Button buttonClick={routeIt} value="Login" />
        <Button buttonClick={routeIt} value="Register" />
        <Login/>
        <hr/>
        <Register/>
    </div>
  )
}

export default UserApp