import React from 'react'

const PasswordField = ({labelValue}) => {
  return (
    
    <div className="form-group">
    <label  className="form-label">{labelValue}</label>
    <input type="password" className="form-control" />
    
  </div>
    
  )
}

export default PasswordField