import React from 'react'

const TextField = ({labelValue}) => {
  return (
    
    <div className="form-group">
    <label  className="form-label">{labelValue}</label>
    <input type="text" className="form-control" />
    
  </div>
    
  )
}

export default TextField